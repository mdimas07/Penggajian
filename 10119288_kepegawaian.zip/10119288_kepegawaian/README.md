Website Penggajian Karyawan Menggunakan Codeigniter 3

Fitur Admin
1. CRUD Data Karyawan
2. CRUD Data Jabatan
3. Setting Potongan Gaji
4. Tambah Data Absensi Karyawan
5. Data Gaji
6. Laporan Gaji
7. Laporan Absensi
8. Cetak Slip Gaji

Fitur Karyawan
1. Cetak Slip Gaji